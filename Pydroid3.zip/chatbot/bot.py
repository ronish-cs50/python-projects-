import json
from difflib import get_close_matches
quit_commands = ['q','quit','0']

def best_match(question,dictionary):
	best_match = get_close_matches(question,dictionary,1,0.8)
	
	
	return best_match 
def load_data_base(path):
	with open(path,'r') as file:
		data = json.load(file)
		
	return data
def update_data_base(ans,prompt):
	data.update({prompt:ans})
	with open('data_base.json','w') as file:
		json.dump(data,file,indent=4)
while True:
	prompt = input('>> ').lower()
	if prompt in quit_commands:
		quit()
	
	data = load_data_base('data_base.json')

		
	new_prompt = best_match(prompt,data)
	
	if new_prompt != []:
		if new_prompt == ['db']:
			print(data)
		prompt == new_prompt
		#print(prompt)
		#print(new_prompt)
		print(data[new_prompt[0]])
	elif prompt not in data:
		ans = input('Please help me learn a suitable answer for this question: ')
		if ans != '':
			update_data_base(ans,prompt)
					
		
	