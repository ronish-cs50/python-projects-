import pygame
import random
import threading
import time
from kivymd.toast import toast
pygame.init()

screen_width = 990
screen_height = 2000


rocks = []

def increase_time():
	global points
	points = 0
	global m
	m = 0
	
	while True:
		time.sleep(1)
		m += 1
		if len(rocks) > 20:
			toast(f'You lost.Rectangles are not in your controll.You killed {points} rectangles in {m}s')
			
			
			screen.fill((0,0,0))
			phrase = myfont.render(f"Click to start", 1, (255, 255, 255))
			screen.blit(phrase,(370,1000))
			time.sleep(6)
			m = 0
			rocks.clear()
			points = 0
			screen.fill((0,0,0))
					
				
			
			
			
			

myfont = pygame.font.SysFont("Arial", 64)
def reset():
	
	
	points -= points
def draw():
	

	while True:
		x = random.randint(1,900)
		y = random.randint(1,1950)
		rect = pygame.Rect(x, y, 80, 80)
		rocks.append(rect)
		#print(rect[0],rect[1])
		point = myfont.render(f"Points : {points}", 1, (255, 255, 255))
		times = myfont.render(f"Time: {m}", 1, (255, 255, 255))
		screen.fill((0,0,0))
		screen.blit(point, (0, 0))
		screen.blit(times, (800, 0))
		for rects in rocks:
			pygame.draw.rect(screen,(200,0,0),rects)
		
		
		#print(m)
		if m < 30:	
			time.sleep(1)
		elif m < 40:
			time.sleep(0.7)
		elif m < 50:
			time.sleep(0.5)
		elif m < 60:
			time.sleep(0.3)
		else:
			time.sleep(0.2)
			
		if len(rocks) > 20:
			
			pass
			

			#rocks.clear()
			
			
		
		
		
		
		
	
	
	
	
	
screen = pygame.display.set_mode((screen_width,screen_height))





		
			
			
	#pygame.display.update()
	
def main():
	
	
	threading.Thread(target=increase_time).start()
	threading.Thread(target=draw).start()
	running = True
		
	while True:
		
		
		for event in pygame.event.get():
			if event.type == pygame.QUIT:
				running = False
			if event.type == pygame.MOUSEBUTTONDOWN:
				k = pygame.mouse.get_pos()
				
				for rects in rocks:
					
					
					if rects.collidepoint(k):
						rocks.remove(rects)
						
						
						global points
						points += 1
						times = myfont.render(f"Time: {m}", 1, (255, 255, 255))
						point = myfont.render(f"Points : {points}", 1, (255, 255, 255))
						screen.fill((0,0,0))
						screen.blit(point, (0, 0))
						screen.blit(times, (800, 0))
						for rect in rocks:
							pygame.draw.rect(screen,(200,0,0),rect)
							
							
		pygame.display.flip()	
									
		
		
	
def menu():			
	while True:
		phrase = myfont.render(f"Click to start", 1, (255, 255, 255))
		
		for ev in pygame.event.get():
			screen.blit(phrase,(370,1000))
			
			if ev.type == pygame.FINGERDOWN:
				main()
		pygame.display.update()
	
menu()			
		
