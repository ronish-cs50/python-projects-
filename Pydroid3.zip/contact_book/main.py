import json
print('r:read,q:quit,y:add new')
def add_contact():
	name = input('Name: ')
	number = input('Number: ')
	contacts = get_contacts()
	numbers = [ contacts[i] for i in contacts]
	
	if name in contacts:
		
		user = input('It is aleardy Saved.Overwrite the number(y-n): ').lower()
		if user == 'y':	
			contacts[name] = number
			with open('contacts.json','w') as file:
				json.dump(contacts,file,indent=4)
	elif number in numbers:
		 print('The number is already Saved.')
	else:
		contacts[name] = number
		with open('contacts.json','w') as file:
			json.dump(contacts,file,indent=4)
	
	
def get_contacts():
	with open('contacts.json','r') as file:
		contacts = json.load(file)
		return contacts

#print('Contact Book')
def main():
	option = input('Do you want new contacts(y-q-r): ').lower()
	if option == 'y':
		add_contact()
		main()
	elif option == 'r':
		print(get_contacts())
		main()
	elif option == 'q':
		quit()
		
	else:
		print('Invalid option')
		main()
	
main()		