from difflib import get_close_matches
from PyDictionary import PyDictionary

dict = PyDictionary()






print('Spelling checker')


with open('words.txt','r') as f:
	words = f.read()
	words = list(words.split('\n'))
def get_best_match(word,file):
	best_match = get_close_matches(word,file,1,0.7)
	return best_match
while True:
	word = input('Please enter word to check: ')
	if word in words or word.upper() in words or word.lower() in words or word.capitalize() in words:
		print(f'The word {word} is correct.')
		meaning = dict.meaning(word)
		if meaning != None:
			print(meaning)
		
	else:
		print('Word Not find')
		print('Check the spelling or try with all uppercsse or lowercase')
		suggestion = get_best_match(word,words)
		if suggestion != []:
			print(f'We recommend {suggestion}.',end = ' ')
			meaning = dict.meaning(suggestion[0])
			if meaning != None:
				print(meaning)


for word in words[:10]:
	k = dict.meaning(word)
	print(word,k)
	if k == None:
		print(word)

