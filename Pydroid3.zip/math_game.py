import tkinter as tk
import random
from functools import partial
from kivymd.toast import toast
points = 0


def main():
	
	screen = tk.Tk()
	def check(arg,num1,num2 ,anss):
		ans = ans_en.get()
		
		try :
			ans_en.destroy()
			question_add.destroy()
			submit_btn.destroy()
		except Exception as e:
			print(e)
		if arg == '+':
			
			try:
				#print(ans.get())
				
				ans = int(ans)
				if ans == (num1 + num2):
					print('Correct')
					toast('Correct')
					do('+')
					#points += 1
				else:
					print('incorrect')
					toast('Incorrect')
					do('+')
			except Exception as e:
					print(e)
					print('k')
					do('+')
		if arg == '-':
			
			try:
				#print(ans.get())
				
				ans = int(ans)
				if ans == (num1 - num2):
					print('Correct')
					toast('Correct')
					do('-')
					#points += 1
				else:
					print('incorrect')
					toast('Incorrect')
					do('-')
			except Exception as e:
					print(e)
					#print('k')
					do('-')			
					
		if arg == '*':
			
			try:
				#print(ans.get())
				
				ans = int(ans)
				if ans == (num1 * num2):
					print('Correct')
					toast('Correct')
					do('*')
					#points += 1
				else:
					print('incorrect')
					toast('Incorrect')
					do('*')
			except Exception as e:
					print(e)
					#print('k')
					do('*')						
					
		if arg == '/':
			
			try:
				#print(ans.get())
				
				ans = int(ans)
				if ans == (num1 / num2):
					print('Correct')
					toast('Correct')
					do('/')
					#points += 1
				else:
					print('incorrect')
					toast('Incorrect')
					do('/')
			except Exception as e:
					print(e)
					#print('k')
					do('/')						
					
					
					
					
	def do(arg):

		add_btn.destroy()
		sub_btn.destroy()
		multiply_btn.destroy()
		divide_btn.destroy()
		global question_add
		global ans_en
		global submit_btn
		num1 = random.randint(1,1000)
		num2 = random.randint(1,1000)
		question_add = tk.Label(screen ,text=f'Find {num1} {arg} {num2}')
		question_add.pack()
		ans_en = tk.Entry(screen)
		ans_en.pack()
		submit_btn = tk.Button(text='Check', command = partial(check,arg,num1 ,num2 ,ans_en))
		submit_btn.pack()
		
		
	def sub():
		add_btn.destroy()
		sub_btn.destroy()
		multiply_btn.destroy()
		divide_btn.destroy()
	
	
	
	
	
	
	
	add_btn = tk.Button(screen ,text='Addition',command = partial(do,'+'))
	add_btn.pack()
	sub_btn = tk.Button(screen,text='Subraction',command = partial(do ,'-'))
	sub_btn.pack()
	multiply_btn = tk.Button(screen ,text='Multiplication' , command=partial(do ,'*'))
	multiply_btn.pack()
	divide_btn = tk.Button(screen ,text='Division',command = partial(do ,'/'))
	divide_btn.pack()
	
	
	screen.mainloop()
	
main()