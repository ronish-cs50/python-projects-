import tkinter as tk
from tkinter import ttk
from functools import partial
from kivymd.toast import toast
from datetime import datetime
#import time


def get_date():
	
	now = datetime.now()
 

	dt_string = now.strftime("%d/%m/%Y-%H:%M:%S")
	return dt_string
	print("date and time =", dt_string)

get_date()
def withdraw(withdraw_amount):
		
		total = 0
		with open('deposits.txt','r') as f:
		
			for x in f:
				x = x.split(' ',1)
				x = x[1]
				
				total = total + int(x)
		with open('deposits.txt','a+') as f:
			withdraw_amount = withdraw_amount.get()
			

			total = int(total)
			if (total - withdraw_amount) <= -1:
				toast('Insufficient Balance')
			else:
				k = get_date()	
				f.write(f'{k} {-withdraw_amount}\n')
				
				
				
				
				
				


				

		
		
def withdraw_win():
	withdraw_window = tk.Tk()
	withdraw_window.geometry('500x500')
	withdraw_window.title('Withdraw')
	withdraw_amount = tk.IntVar(withdraw_window,value = 1)
	amount = ttk.Entry(withdraw_window,textvariable=withdraw_amount)
	amount.pack()
	withdraw_btn = ttk.Button(withdraw_window,text='Withdraw Amount',command=partial(withdraw,withdraw_amount))
	withdraw_btn.pack()
	withdraw_window.mainloop()		
		
def show_total(str = 'Your total balance is'):
	total = 0
	with open('deposits.txt','r') as f:
		
		for x in f:
			x = x.split(' ',1)
			x = x[1]
			print(x)
			total = total + int(x)
			
		toast(f'{str} {total} :)')
		



def deposit(deposit_amount):
	with open('deposits.txt','a+') as f:
		k = get_date()
		
		


		f.write(f'{k} {deposit_amount.get()}\n')
		#time.sleep(0.2)
		#show_total('Balance After deposit is')	

		
	

def deposit_win():
	deposit_window = tk.Tk()
	deposit_window.geometry('500x500')
	deposit_window.title('Deposit')
	deposit_amount = tk.IntVar(deposit_window,value = 1)
	amount = ttk.Entry(deposit_window,textvariable=deposit_amount)
	amount.pack()
	deposit_btn = ttk.Button(deposit_window,text='Deposit Amount',command=partial(deposit,deposit_amount))
	deposit_btn.pack()
	deposit_window.mainloop()

def main():	
	window = tk.Tk()
	deposit_win_btn = ttk.Button(window,text='Deposit',command=deposit_win)
	withdraw_btn = ttk.Button(window,text='Withdraw',command = withdraw_win)
	total_btn = ttk.Button(window,text='Total',command=show_total)
	
	deposit_win_btn.pack()
	withdraw_btn.pack()
	total_btn.pack()
	window.mainloop()
	
	
if __name__ == '__main__':
	main()